from __future__ import annotations

from src.spiralverse.aethermoor_spiral_engine import (
    Action,
    AethermoorSpiralEngine,
    run_demo,
)


def test_world_generation_is_deterministic_by_seed() -> None:
    a = AethermoorSpiralEngine(seed=123, region_count=8)
    b = AethermoorSpiralEngine(seed=123, region_count=8)
    hazards_a = [round(r.hazard, 8) for r in a.world]
    hazards_b = [round(r.hazard, 8) for r in b.world]
    assert hazards_a == hazards_b


def test_sheaf_obstruction_penalizes_stability() -> None:
    eng = AethermoorSpiralEngine(seed=5, region_count=8)
    stable, obs = eng._triadic_obstruction(distance=0.9, entropy=0.8, trust=0.1)  # noqa: SLF001
    assert obs >= 1
    assert 0.0 <= stable <= 1.0


def test_crafting_consumes_resources_and_creates_item() -> None:
    eng = AethermoorSpiralEngine(seed=9, region_count=8)
    eng.inventory.alloy = 3
    eng.inventory.crystal = 2
    before_alloy = eng.inventory.alloy
    ok = eng.craft("consensus_seal")
    assert ok is True
    assert eng.inventory.consensus_seal == 1
    assert eng.inventory.alloy == before_alloy - 2


def test_step_produces_valid_decision_and_progress_fields() -> None:
    eng = AethermoorSpiralEngine(seed=21, region_count=10)
    out = eng.step(Action.ROUTE)
    assert out.decision in {"ALLOW", "QUARANTINE", "DENY", "EXILE"}
    assert 0.0 <= out.omega <= 1.0
    assert out.permission_color in {"green", "amber", "red"}
    assert out.friction_multiplier >= 1.0
    assert out.weakest_lock in {"pqc_factor", "harm_score", "drift_factor", "triadic_stable", "spectral_score", "trust_exile"}
    assert isinstance(out.lock_vector, dict)
    assert "harm_score" in out.lock_vector
    routed, target = out.mission_progress
    assert 0 <= routed <= target


def test_run_demo_is_reproducible() -> None:
    a = run_demo(seed=17, turns=10)
    b = run_demo(seed=17, turns=10)
    assert a["final"]["mission"] == b["final"]["mission"]
    proj_a = [(h["tick"], h["action"], h["decision"], tuple(h["progress"])) for h in a["history"]]
    proj_b = [(h["tick"], h["action"], h["decision"], tuple(h["progress"])) for h in b["history"]]
    assert proj_a == proj_b
