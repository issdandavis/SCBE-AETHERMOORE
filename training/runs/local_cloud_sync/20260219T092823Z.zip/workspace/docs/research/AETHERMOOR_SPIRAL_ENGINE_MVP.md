# Aethermoor Spiral Engine MVP

Status: `prototype`

## What this adds

File: `src/spiralverse/aethermoor_spiral_engine.py`

The module turns SCBE governance signals into a game loop with:

1. Procedural exploration map (`Region` generation by seed)
2. Inventory + crafting (`consensus_seal`, `spectral_filter`)
3. Skill progression (`tongue` levels + skill points)
4. Mission routing with `ALLOW/QUARANTINE/DENY/EXILE`
5. Sheaf consistency gate using Tarski lattice operators (`src/harmonic/tarski_sheaf.py`)

## Math chain in the loop

Each turn computes:

- Distance pressure from region hazard
- Temporal intent accumulation (`TemporalSecurityGate`)
- Harmonic wall cost `H_eff = R^(d^2 * x)` (inside temporal gate)
- Sheaf obstruction count on temporal nodes `{Ti, Tm, Tg}`
- Triadic stability `= 1 - obstruction_count / 3`
- Omega gate:
  - `Omega = pqc_valid * harm_score * drift_factor * triadic_stable * spectral_score`

Decision thresholds come from `TemporalSecurityGate`:

- `ALLOW` if omega > `0.85`
- `QUARANTINE` if omega > `0.40`
- otherwise `DENY`
- `EXILE` when sustained low trust triggers exile state

## Demo

```bash
python scripts/aethermoor_spiral_demo.py --seed 7 --turns 12 --output-json artifacts/aethermoor/spiral_demo.json
```

## Tests

File: `tests/test_aethermoor_spiral_engine.py`

Coverage:

- deterministic world generation for same seed
- sheaf obstruction influences stability
- crafting resource consumption + output
- valid decision/omega per turn
- deterministic replay for same seed/turns

