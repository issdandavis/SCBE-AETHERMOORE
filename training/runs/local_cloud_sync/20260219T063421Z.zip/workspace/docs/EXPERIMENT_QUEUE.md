# Experiment Queue

Last updated: February 19, 2026
Owner: SCBE core team

## Objective
Convert unproven and conflicting claims into reproducible pass/fail decisions.

## Global Protocol
- Dataset must be versioned and immutable for each run.
- Seed set must be fixed and logged.
- All methods must run in same harness.
- Report: AUC, F1, latency, confidence intervals, and failure slices.

## Priority Queue

### Q0 - Reproducibility Gate (run first)
Status: OPEN
Goal: Reconcile conflicting metrics across existing artifacts.
Inputs:
- `experiments/hyperbolic_experiment_results.json`
- `experiments/pipeline_vs_baseline_results.json`
- `experiments/three_mechanism_results.json`
Pass criteria:
- Single adjudicated protocol committed at `experiments/protocol_v1.md`
- Re-run artifacts generated from one script and one dataset spec
Fail criteria:
- Any metric remains non-reproducible within tolerance

### Q1 - LWS vs Uniform Weighting
Status: OPEN
Goal: Determine if Layer 3 weighting improves real detection quality.
Baselines: Uniform weighting, simple scalar weighting.
Pass criteria:
- Delta AUC >= +0.02 over best baseline and p < 0.01
- No latency increase above 20 percent
Fail criteria:
- No significant gain or severe latency regression

### Q2 - Spectral Coherence Value Test
Status: OPEN
Goal: Test Layer 9/10 features against traffic manipulation attacks.
Baselines: Phase-only, drift-only, phase+drift.
Pass criteria:
- Spectral-enabled model improves recall at fixed 5 percent FPR
- Improvement replicated across 3 attack families
Fail criteria:
- Spectral features add no measurable value

### Q3 - PHDM Traceability Test
Status: OPEN
Goal: Validate whether PHDM path constraints improve audit traceability.
Metric:
- Mean time to localize anomaly source layer
- Trace compression ratio and replay determinism
Pass criteria:
- At least 25 percent faster anomaly localization vs non-PHDM path logging
Fail criteria:
- Equivalent or worse traceability than simpler logging

### Q4 - Flux-State Routing Under Pressure
Status: OPEN
Goal: Test if flux state routing bounds error propagation under attack load.
Metric:
- Drift growth slope under pressure
- Recovery time to baseline
Pass criteria:
- Lower drift growth and faster recovery than no-flux controller
Fail criteria:
- No containment advantage

### Q5 - Cross-Language Parity (TS vs Python)
Status: OPEN
Goal: Prove SS1 and core scoring parity across implementations.
Inputs:
- `src/harmonic/*`
- `src/symphonic_cipher/*`
Pass criteria:
- Deterministic parity vectors pass at 100 percent
Fail criteria:
- Any divergence on canonical vectors

## Delivery Template Per Experiment
- `experiments/<name>.py` or `.ts`
- `experiments/<name>_results.json`
- `artifacts/<name>_report.png` (optional)
- `docs/evidence/<name>.md`

## Decision Ladder
- `OPEN` -> `RUNNING` -> `PASS` or `FAIL`
- `PASS` with reproducibility only upgrades claim status.
