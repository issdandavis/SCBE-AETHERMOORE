# Language Guardrails

Last updated: February 19, 2026
Purpose: Keep technical docs patent-safe, testable, and non-hype.

## Core Rule
Only claim what is measured, reproducible, and tied to a defined protocol.

## Allowed Claim Verbs
- measured
- reproduced
- observed
- bounded
- detected
- failed

## Restricted Phrases (Replace or Remove)

| Avoid | Use Instead |
|---|---|
| mathematically impossible | denied by current threshold policy |
| unbreakable | not evaluated against full adversarial model |
| perfect security | no failures observed in current test scope |
| production-ready (without SLO evidence) | prototype implemented |
| constant-time | timing behavior not constant-time verified |
| no prior art | prior art review pending |
| 518,400x security | weighted policy score multiplier |
| geometric firewall (as hardness claim) | geometric risk scoring layer |
| Byzantine fault tolerant (if majority vote only) | quorum majority consensus |

## Evidence Annotation Standard
Every non-trivial claim must include:
1. Metric name and value.
2. Dataset/protocol reference.
3. Artifact path.
4. Date.

Example:
- Combined detector AUC = 0.9942 on six attack classes (`experiments/three_mechanism_results.json`, 2026-02-06).

## Status Tags to Use in Docs
- `[PROVEN]`
- `[DISPROVEN]`
- `[CODE_EXISTS_UNTESTED]`
- `[REPORTED_PENDING_REPRO]`

## Formula Regime Tags (Required)
- `[WALL_ENFORCEMENT]`
- `[PATROL_MONITORING]`
- `[BOUNDED_SCORING]`
- `[EXPERIMENTAL]`

Any use of `H(...)` must include one regime tag and a formula identifier.
Do not reuse `H` across regimes in the same section without explicit mapping.

## Patent-safe Writing Pattern
- Start with mechanism description.
- State tested scope.
- State limitation.
- Avoid universals (always, never, impossible) unless formally proven and scoped.

## Pre-merge Checklist (Docs)
- Claim has artifact path.
- Numbers match source JSON.
- No restricted phrase remains.
- Status tag present on each major claim.
- Conflicts with `CLAIMS_EVIDENCE_LEDGER.md` resolved or explicitly marked.
- Formula regime tags present for every harmonic/scoring formula.
