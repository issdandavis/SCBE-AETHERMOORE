# Claims Evidence Ledger

Last updated: February 19, 2026
Source of truth: `docs/CLAIMS_AUDIT_V4.md`

## Purpose
This ledger is the operational record for claim status, evidence quality, and promotion gates.
No claim moves to `PROVEN` without reproducible artifacts.

## Status Definitions
- `PROVEN`: Reproduced with code + artifacts + baseline comparison.
- `DISPROVEN`: Tested and failed under defined protocol.
- `CODE_EXISTS_UNTESTED`: Implemented but not benchmarked against baseline.
- `REPORTED_PENDING_REPRO`: Reported in notes/docs but not reproducibly confirmed.

## Claim Table

| ID | Claim | Current Status | Evidence Files | Promotion Gate |
|---|---|---|---|---|
| A | Phase plus distance adversarial detection | PROVEN | `docs/CLAIMS_AUDIT_V4.md`, `experiments/three_mechanism_results.json` | Re-run on frozen real embedding corpus with CI artifact hash |
| B | SS1 six-tongue bijective encoding | PROVEN | `docs/CLAIMS_AUDIT_V4.md`, `tests/test_sacred_eggs.py`, `tests/test_sacred_eggs_ref.py` | Cross-language parity report (TS/Python) |
| E | Decimal drift signature detection | PROVEN | `docs/CLAIMS_AUDIT_V4.md`, `tests/harmonic/driftTracker.test.ts`, `src/harmonic/driftTracker.ts` | External replay test set with held-out attacks |
| F | Epoch-chirped 6-tonic anti-replay | PROVEN | `docs/CLAIMS_AUDIT_V4.md`, `experiments/three_mechanism_results.json` | Clock-skew robustness sweep (+/- 40ms) |
| G | Three-mechanism combined defense-in-depth | PROVEN | `docs/CLAIMS_AUDIT_V4.md`, `experiments/three_mechanism_results.json` | Independent rerun with seed lock and confidence intervals |
| H | Sacred Eggs predicate-gated distribution | PROVEN | `docs/CLAIMS_AUDIT_V4.md`, `experiments/sacred_eggs_results.json` | Side-channel and timing profile report |
| X1 | Single-point hyperbolic superiority over Euclidean | DISPROVEN | `docs/CLAIMS_AUDIT_V4.md` | Closed unless task definition changes |
| X2 | GeoSeal swarm as primary detector | DISPROVEN | `docs/CLAIMS_AUDIT_V4.md`, `tests/test_geoseal.py`, `tests/test_geoseal_v2.py` | New mechanism required, not parameter tuning |
| X3 | Constant-time behavior in Python stack | DISPROVEN | `docs/CLAIMS_AUDIT_V4.md` | Must move critical path to constant-time primitives |
| X4 | Tripoint centroid hyperbolic advantage | DISPROVEN | `docs/CLAIMS_AUDIT_V4.md` | Re-open only with new non-origin task and full baseline set |
| C | 14-layer governance pipeline as auditable detector | CODE_EXISTS_UNTESTED | `src/governance/audit_ledger.ts`, `experiments/pipeline_vs_baseline_results.json` | Resolve conflicting results and publish final protocol |
| D | PHDM containment improves traceability | CODE_EXISTS_UNTESTED | `docs/PHDM_BRAIN_ARCHITECTURE.md` | Define measurable traceability metric and run A/B |
| LWS | Golden-ratio weighting improves decision quality | CODE_EXISTS_UNTESTED | `docs/CLAIMS_AUDIT_V4.md` | Uniform-vs-LWS controlled experiment |
| Spectral | Layer 9/10 spectral coherence adds detection value | CODE_EXISTS_UNTESTED | `docs/CLAIMS_AUDIT_V4.md` | Traffic manipulation benchmark vs simpler features |

## Conflicts Requiring Adjudication

### Conflict C-1: Hyperbolic benchmark artifacts disagree
- `docs/CLAIMS_AUDIT_V4.md` reports `d_H = d_E` in origin-centered setup.
- `experiments/hyperbolic_experiment_results.json` reports different means in another setup.
- Resolution rule: mark as `REPORTED_PENDING_REPRO` if protocol mismatch exists.

### Conflict C-2: Pipeline superiority artifacts disagree
- `docs/CLAIMS_AUDIT_V4.md` frames combined mechanism as strong on real pipeline.
- `experiments/pipeline_vs_baseline_results.json` shows conditions where simpler baselines win.
- Resolution rule: freeze one canonical protocol, rerun all models, publish single adjudicated result.

### Conflict C-3: Harmonic formula family drift across code and docs
- `packages/kernel/src/harmonicScaling.ts` uses bounded score `1/(1+d+2*pd)`.
- `harmonic_scaling_law.py` uses `exp(d^2)`.
- `src/symphonic_cipher/core/harmonic_scaling_law.py` uses `R^(d^2)`.
- Prior templates and constants also reference patrol form `R*pi^(phi*d)`.
- Resolution rule: enforce regime tags and formula IDs before claim publication.

## Claim Promotion Rules
1. One canonical dataset spec and seed file.
2. One canonical evaluation script path.
3. JSON artifact with metrics and confidence intervals.
4. Baseline comparisons included in same run.
5. Reviewer sign-off entry in this ledger.

## Reviewer Sign-off Log

| Date | Claim ID | Decision | Reviewer | Notes |
|---|---|---|---|---|
| 2026-02-19 | Initial | Created | Codex | Initialized from Claims Audit v4 and local experiment artifacts |
