# SCBE Notion Workspace -- Setup Guide

## Step 1: Create Your Hub Page

1. In Notion, create a new top-level page: **"SCBE Operations Hub"**
2. Add an icon (suggested: shield or gear emoji)
3. Add a cover image (use any SCBE/Aethermoor art)

## Step 2: Import Databases

For each CSV file in `notion_export/`, create a database:

### Import Process (per database)
1. On your hub page, type `/database` and select "Table - Full page"
2. Name it according to the CSV filename
3. Click the "..." menu in the top-right of the table
4. Select "Merge with CSV" (or "Import" depending on your Notion version)
5. Upload the corresponding CSV
6. After import, adjust column types:
   - **Select** columns: Click the column header > Edit property > Change type to "Select"
   - **Multi-select** columns: Change type to "Multi-select"
   - **Date** columns: Change type to "Date"
   - **Number** columns: Change type to "Number" and set format to USD where noted
   - **Checkbox** columns: Change type to "Checkbox"
   - **Person** columns: Change type to "Person" (will need to re-assign to your team)

### Recommended Import Order
1. People & Roles (reference table for others)
2. Project Tracker
3. Bug & Issue Tracker
4. Release Coordination
5. Revenue Records

## Step 3: Add Database Views

After importing each database, add these views:

### Project Tracker Views
- **Board**: Group by Status (Planning > Active > Paused > Complete)
- **By Risk**: Table filtered and sorted by Risk Level descending
- **Timeline**: Timeline view using Start Date and Target Date
- **Revenue Impact**: Table sorted by Revenue Impact descending

### Bug & Issue Tracker Views
- **Open Bugs**: Table filtered to Status != Resolved, != Closed
- **Critical Path**: Table filtered to P0 + P1
- **By Layer**: Board grouped by Affected Layers
- **By Component**: Board grouped by Component

### Release Coordination Views
- **Pipeline**: Board grouped by Status
- **Upcoming**: Table filtered to Status = Planning, Development, Testing
- **Needs Sign-off**: Table filtered to Governance Sign-off = unchecked

### Revenue Records Views
- **By Product**: Board grouped by Product
- **By Channel**: Board grouped by Channel
- **Monthly**: Table sorted by Date, grouped by month
- **Recurring Only**: Table filtered to Recurring = checked

## Step 4: Add Page Templates

Copy the content from each file in `templates/` into a new Notion page under your hub:

1. Create a "Templates" section on your hub page
2. For each template, create a sub-page and paste the markdown content
3. In Notion, you can convert these into database templates by:
   - Opening a database
   - Clicking "New" dropdown arrow
   - "New template"
   - Paste the template content

## Step 5: Create the Dashboard

1. Create a new page: "Daily Ops Dashboard"
2. Follow the layout in `dashboard/daily_ops_dashboard.md`
3. Add linked database views from your imported databases
4. Pin this page to your sidebar for quick access

## Step 6: Connect Relations (Optional)

Link your databases together:
- Release Coordination > Related Projects (Relation to Project Tracker)
- Bug Tracker > Related Release (Relation to Release Coordination)
- Project Tracker > Team (Relation to People & Roles)

## Tips

- Use the "Lock page" feature on templates so they do not get accidentally edited
- Set up Notion automations to notify you when a P0 bug is created
- Use the Notion API to connect these databases to your n8n workflows
- The governance fields are designed to match the SCBE 14-layer model -- customize thresholds for your domain
