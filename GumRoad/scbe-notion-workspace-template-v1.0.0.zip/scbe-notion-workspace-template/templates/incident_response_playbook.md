# Incident Response Playbook

## Severity Levels

| Level | Description | Response Time | Escalation |
|-------|-------------|---------------|------------|
| P0 - Critical | Agent producing harmful output, data breach | Immediate | All hands |
| P1 - High | Governance bypass detected, incorrect risk decisions | < 1 hour | Team lead + admin |
| P2 - Medium | Drift detected, quality degradation | < 4 hours | Assigned engineer |
| P3 - Low | Minor anomaly, cosmetic issue | < 24 hours | Ticket queue |

---

## Step 1: Detect and Classify

- [ ] What triggered the alert? (Monitor / User report / Automated scan)
- [ ] Which agent(s) are involved?
- [ ] What layer(s) are affected?
- [ ] Classify severity: P0 / P1 / P2 / P3
- [ ] Is user data at risk? YES / NO

## Step 2: Contain

### For P0/P1:
- [ ] Immediately quarantine the affected agent(s)
- [ ] Disable the workflow/endpoint if publishing is involved
- [ ] Preserve all logs and telemetry (do not delete)
- [ ] Notify stakeholders

### For P2/P3:
- [ ] Flag the agent for monitoring
- [ ] Create a bug tracker entry with affected layers
- [ ] Continue operations with increased logging

## Step 3: Investigate

- [ ] Pull governance scan results for the affected time window
- [ ] Review hyperbolic distance trajectory (was drift gradual or sudden?)
- [ ] Check for upstream data poisoning
- [ ] Examine prompt history for injection attempts
- [ ] Compare current behavior against baseline metrics

## Step 4: Remediate

- [ ] Identify root cause
- [ ] Apply fix (configuration change / code patch / model update)
- [ ] Test fix in isolated environment
- [ ] Run governance scan on the fix itself
- [ ] Deploy with monitoring

## Step 5: Recover

- [ ] Restore normal operations
- [ ] Verify all agents are back within governance bounds
- [ ] Clear quarantine flags
- [ ] Update threat library with new pattern (if applicable)

## Step 6: Post-Mortem

- [ ] Timeline of events documented
- [ ] Root cause analysis complete
- [ ] Preventive measures identified
- [ ] Governance thresholds adjusted (if needed)
- [ ] Post-mortem shared with team
- [ ] Knowledge base updated
