# New Agent Onboarding

**Agent Name**: _______________
**Agent Type**: [ ] Browser  [ ] Content  [ ] Research  [ ] Code  [ ] Custom
**Onboarding Date**: _______________
**Assigned Sacred Tongue**: [ ] KO  [ ] AV  [ ] RU  [ ] CA  [ ] UM  [ ] DR

---

## Pre-Deployment Checklist

### Identity Setup
- [ ] Generate agent identity (GeoSeal or equivalent)
- [ ] Assign governance clearance level (Observer / Contributor / Reviewer)
- [ ] Set access tier (Free: 100/day, Earned: 1000/day, Paid: unlimited)
- [ ] Register in People & Roles database

### Governance Configuration
- [ ] Define allowed operations (explicit whitelist)
- [ ] Set risk thresholds (ALLOW / QUARANTINE / ESCALATE / DENY boundaries)
- [ ] Configure drift detection parameters
  - ON_TRACK threshold: < 0.3
  - GENTLE correction: 0.3 - 0.7
  - REDIRECT: 0.7 - 1.2
  - INSPECT: 1.2 - 2.0
  - QUARANTINE: > 2.0
- [ ] Assign ephemeral prompt strategy (GPS-style nudges)

### Integration
- [ ] Connect to monitoring pipeline
- [ ] Verify health check endpoint responds
- [ ] Test governance scan on sample operations
- [ ] Confirm telemetry logging is active
- [ ] Add to fleet heartbeat monitor

## Validation Tests

- [ ] Submit 5 known-safe operations -- all should ALLOW
- [ ] Submit 3 edge-case operations -- should QUARANTINE or ESCALATE
- [ ] Submit 1 known-adversarial operation -- should DENY
- [ ] Verify drift detection triggers at expected thresholds
- [ ] Confirm ephemeral prompts fire correctly

## Sign-off

- [ ] All validation tests pass
- [ ] Agent added to production fleet
- [ ] Monitoring dashboard updated
- [ ] Team notified of new agent
- [ ] Onboarding record saved

Onboarded by: _______________ Date: _______________
