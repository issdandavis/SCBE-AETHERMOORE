# Dataset Publishing Workflow

**Dataset Name**: _______________
**Target Repository**: _______________
**Publishing Date**: _______________
**Governance Reviewer**: _______________

---

## Step 1: Data Collection

- [ ] Identify source data locations:
  - [ ] Local training files (`training/intake/`)
  - [ ] Obsidian vault exports
  - [ ] Browser swarm research results
  - [ ] Game combat blockchain exports
  - [ ] Notion page extracts
  - [ ] Telegram conversation logs
- [ ] Estimate record count: _______________
- [ ] Estimate data size: _______________

## Step 2: Data Cleaning

- [ ] Remove duplicates (hash-based dedup)
- [ ] Strip personally identifiable information (PII)
- [ ] Remove any API keys, tokens, or secrets
- [ ] Validate JSON/JSONL formatting
- [ ] Check encoding (UTF-8 required)
- [ ] Run basic quality metrics:
  - Average record length: ___
  - Null/empty fields: ___%
  - Language distribution: ___

## Step 3: Governance Scan

- [ ] Run governance scan on full dataset:
  ```
  POST /v1/governance/scan
  ```
- [ ] Review scan results:
  - Records passed: ___
  - Records flagged: ___
  - Records blocked: ___
- [ ] Manually review all flagged records
- [ ] Decision on flagged records: [ ] Include  [ ] Exclude  [ ] Modify

## Step 4: Tongue Encoding (Optional)

- [ ] Apply Sacred Tongue encoding for semantic tagging:
  ```
  POST /v1/tongue/encode
  ```
- [ ] Verify tongue weights are within expected range
- [ ] Tag each record with primary tongue classification

## Step 5: Format and Package

- [ ] Convert to target format:
  - [ ] JSONL (for HuggingFace)
  - [ ] CSV (for analysis)
  - [ ] Parquet (for large datasets)
- [ ] Generate dataset card (README.md for HuggingFace)
- [ ] Include metadata:
  - Source information
  - Governance scan report
  - Record count and schema
  - License terms

## Step 6: Publish

- [ ] Push to HuggingFace:
  ```
  POST /v1/vertex/push-to-hf
  ```
- [ ] Verify upload on HuggingFace web UI
- [ ] Check dataset viewer renders correctly
- [ ] Update Airtable with publishing record
- [ ] Create Revenue Records entry (if applicable)

## Step 7: Post-Publish

- [ ] Share dataset link with team
- [ ] Create content pieces about the dataset (for marketing)
- [ ] Schedule next publishing cycle
- [ ] Archive source data with governance audit trail

## Sign-off

Publisher: _______________ Date: _______________
Reviewer: _______________ Date: _______________
