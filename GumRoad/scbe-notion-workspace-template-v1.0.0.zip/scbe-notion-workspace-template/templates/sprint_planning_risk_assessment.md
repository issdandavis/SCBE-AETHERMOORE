# Sprint Planning with Risk Assessment

**Sprint**: _______________
**Dates**: _______________ to _______________
**Team Size**: _______________
**Sprint Goal**: _______________

---

## Capacity Planning

| Team Member | Available Days | Focus Area | Governance Clearance |
|-------------|---------------|------------|---------------------|
| | | | |
| | | | |
| | | | |

**Total capacity**: ___ person-days

## Sprint Backlog with Risk Scores

| Task | Estimate | Risk Level | Affected Layers | Governance Review? |
|------|----------|-----------|-----------------|-------------------|
| | | | | [ ] |
| | | | | [ ] |
| | | | | [ ] |
| | | | | [ ] |
| | | | | [ ] |

## Risk Assessment

### Risk Inventory

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| | Low/Med/High | Low/Med/High | |
| | | | |
| | | | |

### Governance Checkpoints

- [ ] Mid-sprint governance review scheduled for: _______________
- [ ] All L3-Enterprise tasks have a designated reviewer
- [ ] High-risk tasks are paired (no solo work on critical paths)
- [ ] Rollback plans documented for all deployable work

### Layer Impact Summary

| Layer Range | Tasks Touching | Combined Risk |
|-------------|---------------|---------------|
| L1-L4 (Input) | ___ | Low / Med / High |
| L5-L10 (Core) | ___ | Low / Med / High |
| L11-L14 (Decision) | ___ | Low / Med / High |

## Sprint Commitments

- [ ] Sprint goal is achievable within capacity
- [ ] No more than 30% of work is high-risk
- [ ] All high-risk items have governance sign-off before implementation
- [ ] Demo/review scheduled for: _______________
- [ ] Retrospective scheduled for: _______________

## End-of-Sprint Checklist

- [ ] All completed tasks passed governance scan
- [ ] Test coverage maintained or improved
- [ ] No new P0/P1 bugs introduced
- [ ] Training data generated from sprint work (SFT/DPO pairs)
- [ ] Sprint metrics recorded in Project Tracker
- [ ] Retrospective notes documented
