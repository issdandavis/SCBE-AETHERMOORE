# Knowledge Base

## Architecture References

### 14-Layer Pipeline Overview
The SCBE pipeline processes every operation through 14 mathematical layers:

| Layer | Function |
|-------|----------|
| L1-2 | Complex context and realification |
| L3-4 | Weighted transform and Poincare embedding |
| L5 | Hyperbolic distance calculation |
| L6-7 | Breathing transform and Mobius phase |
| L8 | Multi-well realms (Hamiltonian CFI) |
| L9-10 | Spectral and spin coherence (FFT) |
| L11 | Triadic temporal distance |
| L12 | Harmonic wall: H(d,R) = R^(d^2) |
| L13 | Risk decision: ALLOW / QUARANTINE / ESCALATE / DENY |
| L14 | Audio axis (FFT telemetry) |

### Sacred Tongues
6 semantic dimensions with golden ratio weights:
- KO (1.00) -- Core operations
- AV (1.62) -- Adaptive vision
- RU (2.62) -- Rule understanding
- CA (4.24) -- Causal analysis
- UM (6.85) -- Universal mapping
- DR (11.09) -- Deep reasoning

### Risk Decision Tiers
- **ALLOW**: Safe operation, proceed normally
- **QUARANTINE**: Suspicious activity, hold for review
- **ESCALATE**: High risk, requires governance committee
- **DENY**: Adversarial intent detected, blocked

## Operational Runbooks

- See `SCBE_BOOTSTRAP_RUNBOOK.md` for fresh environment setup
- See `N8N_LOCAL_STACK_RUNBOOK.md` for workflow operations
- See `M5_MESH_PRODUCT_SERVICE_BLUEPRINT.md` for product delivery

## Threat Pattern Categories

1. Prompt injection (direct, indirect, multi-turn)
2. Data exfiltration (side-channel, encoding, timing)
3. Privilege escalation (role confusion, context manipulation)
4. Social engineering (trust exploitation, authority spoofing)
5. Resource abuse (compute exhaustion, storage overflow)
