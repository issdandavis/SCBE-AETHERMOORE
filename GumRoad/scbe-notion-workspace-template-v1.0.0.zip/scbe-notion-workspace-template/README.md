# SCBE Notion Workspace Template

**By Issac Davis / AethermoorGames**
**Version**: 1.0.0

---

## What You Get

A complete Notion workspace structure for running AI governance operations. Pre-built databases, page templates, and a daily operations dashboard -- all with governance-aware fields.

### Databases (6)

| Database | Records | Purpose |
|----------|---------|---------|
| **Project Tracker** | 5 sample projects | Projects with governance tier, risk status, patent linkage |
| **Bug & Issue Tracker** | 10 sample issues | Issues tagged with affected layers (L1-L14), severity |
| **Release Coordination** | 3 sample releases | Pipeline with governance sign-off, deployment checklist |
| **Revenue Records** | 6 sample records | Revenue by product, channel, and governance tier |
| **People & Roles** | 4 sample people | Team with governance clearance, domain expertise |
| **Knowledge Base** | — | Reference pages for architecture, specs, runbooks |

### Page Templates (5)

- **Governance Review Checklist** -- Step-by-step review for any governed operation
- **Incident Response Playbook** -- What to do when an agent goes off-track
- **New Agent Onboarding** -- Setup checklist for adding agents to your fleet
- **Dataset Publishing Workflow** -- End-to-end governed data publishing
- **Sprint Planning with Risk Assessment** -- Sprint planning that accounts for AI risk

### Dashboard

- **Daily Ops Dashboard** -- Single-page view with key metrics, active issues, pending releases

---

## Setup Instructions

### Option A: Import CSV Files (Recommended)

1. Open your Notion workspace
2. Create a new page called "SCBE Operations Hub"
3. For each CSV file in `notion_export/`:
   - Create a new database (Table view)
   - Click "..." menu > "Merge with CSV"
   - Import the corresponding CSV file
   - Adjust property types as noted in `SETUP_GUIDE.md`

### Option B: Manual Setup

1. Follow the database schemas in `SETUP_GUIDE.md`
2. Create each database manually with the listed properties
3. Copy page templates from the `templates/` folder
4. Create the dashboard page from `dashboard/daily_ops_dashboard.md`

---

## Database Schemas

### Project Tracker
- Name (Title)
- Status (Select: Planning / Active / Paused / Complete)
- Governance Tier (Select: L1-Basic / L2-Standard / L3-Enterprise)
- Risk Level (Select: Low / Medium / High / Critical)
- Owner (Person)
- Start Date (Date)
- Target Date (Date)
- Revenue Impact (Number, USD)
- Patent Linkage (Text)
- Layer Coverage (Multi-select: L1 through L14)

### Bug & Issue Tracker
- Title (Title)
- Status (Select: Open / In Progress / Blocked / Resolved / Closed)
- Severity (Select: P0-Critical / P1-High / P2-Medium / P3-Low)
- Affected Layers (Multi-select: L1 through L14)
- Component (Select: Pipeline / Crypto / Governance / Spectral / Network / API)
- Reported By (Person)
- Assigned To (Person)
- Date Reported (Date)
- Governance Impact (Checkbox)
- Root Cause (Text)

### Release Coordination
- Release (Title)
- Version (Text)
- Status (Select: Planning / Development / Testing / Staging / Released / Rolled Back)
- Governance Sign-off (Checkbox)
- Risk Assessment (Select: Low / Medium / High)
- Deploy Date (Date)
- Changelog (Text)
- Rollback Plan (Text)
- Related Projects (Relation to Project Tracker)

### Revenue Records
- Description (Title)
- Product (Select: n8n Pack / Governance Toolkit / Spin Engine / HYDRA Templates / Notion Template / Bundle)
- Channel (Select: Gumroad / Stripe / Shopify / Redbubble / Printful / Kindle)
- Amount (Number, USD)
- Date (Date)
- Governance Tier (Select: Free / Standard / Enterprise)
- Recurring (Checkbox)
- Customer (Text)

### People & Roles
- Name (Title)
- Role (Select: Engineer / Researcher / Designer / Ops / Admin)
- Governance Clearance (Select: Observer / Contributor / Reviewer / Admin)
- Domain (Multi-select: Pipeline / Crypto / Governance / Content / Training / Deploy)
- Sacred Tongue (Select: KO / AV / RU / CA / UM / DR)
- Active (Checkbox)

---

## Requirements

- Notion account (free or paid)
- No code or API setup needed
- Works with Notion personal, team, or enterprise plans

## License

Commercial license. Single-workspace. See LICENSE.txt.
