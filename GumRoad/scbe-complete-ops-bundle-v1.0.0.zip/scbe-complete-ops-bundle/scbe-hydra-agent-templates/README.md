# HYDRA Agent Templates

**By Issac Davis / AethermoorGames**
**Version**: 1.0.0

---

## What You Get

Ready-to-use agent configuration templates for building governed AI agent systems.

### Template Library

| Template | Agents | Use Case |
|----------|--------|----------|
| **Browser Research Swarm** | 6 agents (Scout, Vision, Reader, Clicker, Typer, Judge) | Autonomous web research with governance |
| **Content Publisher** | 3 agents (Writer, Editor, Publisher) | Multi-platform content with quality gates |
| **Code Review Team** | 4 agents (Analyzer, Reviewer, Fixer, Verifier) | Automated code review pipeline |
| **Data Ingestion Fleet** | 5 agents (Forager, Scanner, Encoder, Router, Storer) | Governed data collection and storage |
| **Customer Support** | 3 agents (Classifier, Responder, Escalator) | Tiered customer service with safety rails |

### Each Template Includes

- `config.yaml` -- Agent definitions, roles, permissions
- `prompts/` -- System prompts for each agent role
- `governance.yaml` -- Risk thresholds, quarantine rules, escalation paths
- `example.py` -- Working example you can run immediately
- `tests/` -- Validation tests for the template

### Prompt Engineering Patterns

15 battle-tested prompt patterns:
- **Intent Declaration** -- Agents declare intent before acting
- **Governance Checkpoint** -- Pause-and-verify at risk boundaries
- **Sacred Tongue Encoding** -- 6-domain semantic classification
- **Drift Detection** -- Monitor for task drift in real-time
- **Ephemeral Nudge** -- GPS-style course corrections
- **Trust Tube** -- Constrain agent movement to safe corridors
- **Quarantine Protocol** -- Isolate suspicious behavior
- **Fleet Heartbeat** -- Health monitoring across agent swarms
- Plus 7 more...

---

## Quick Start

```python
from hydra_templates import load_template

# Load the browser research swarm
swarm = load_template("browser_research_swarm")

# Configure for your use case
swarm.set_target("https://arxiv.org/list/cs.AI/recent")
swarm.set_governance(risk_threshold=0.3, quarantine=True)

# Run with governance
results = swarm.execute(query="Latest AI safety papers 2026")
```

---

## Requirements

- Python 3.11+
- No external dependencies for templates
- Optional: playwright (for browser templates), openai/anthropic (for LLM agents)

## License

Commercial license. Single-team. See LICENSE.txt.
