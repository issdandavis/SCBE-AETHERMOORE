# SCBE n8n Workflow Starter Pack

**By Issac Davis / AethermoorGames**
**Version**: 1.0.0
**Requires**: n8n (self-hosted or cloud), Python 3.11+, Node 18+

---

## What You Get

12 production-ready n8n workflows + a FastAPI bridge for AI-governed content operations:

| Workflow | What It Does |
|----------|-------------|
| **Content Publisher** | Multi-platform posting (Twitter, LinkedIn, Bluesky, Mastodon) with built-in governance scanning |
| **Web Agent Tasks** | Submit and monitor autonomous web research/posting tasks |
| **M5 Mesh Data Funnel** | Ingest data from Notion, Dropbox, local files into a governed pipeline |
| **Vertex AI + HuggingFace** | Push training data to HuggingFace, trigger model training |
| **X Growth + Merch Ops** | Twitter growth automation with merchandise tie-ins |
| **Asana + AetherBrowse** | Project task scheduling with browser automation |
| **Game Events** | Process in-game events into training data (for game devs) |
| **Telegram Router** | Route Telegram messages through governance before forwarding |
| **Telegram Cloud Webhook** | Cloud-hosted Telegram integration endpoint |
| **LLM Dispatch** | Route prompts to the right LLM based on task type |
| **Notion + GitHub Swarm** | Research swarm pulling from Notion and GitHub |
| **Baserow RSS** | RSS feed monitoring for release tracking |

### FastAPI Bridge (`scbe_n8n_bridge.py`)

Connects n8n to the SCBE governance layer:

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/health` | GET | Health check |
| `/v1/governance/scan` | POST | Scan content for threats before publishing |
| `/v1/tongue/encode` | POST | Sacred Tongue semantic encoding |
| `/v1/agent/task` | POST | Submit web agent task |
| `/v1/training/ingest` | POST | Ingest training data |
| `/v1/buffer/post` | POST | Queue content for publishing |

---

## Quick Start

### 1. Install n8n
```bash
npm install -g n8n
# or
docker run -it --rm -p 5678:5678 n8nio/n8n
```

### 2. Start the Bridge
```bash
pip install fastapi uvicorn
export SCBE_API_KEYS=your-secret-key
python -m uvicorn scbe_n8n_bridge:app --host 127.0.0.1 --port 8001
```

### 3. Import Workflows
```bash
n8n import:workflow --input=workflows/scbe_content_publisher.workflow.json
# Repeat for each workflow you want
```

### 4. Configure Credentials

In the n8n UI (http://localhost:5678):
1. Add your platform API keys (Twitter, Bluesky, etc.)
2. Set the bridge webhook URL to `http://localhost:8001`
3. Set `X-API-Key` header to match your SCBE_API_KEYS

---

## Environment Variables

```bash
SCBE_API_KEYS=your-key           # Bridge authentication
GITHUB_TOKEN=ghp_xxx             # GitHub PAT (for swarm workflows)
BLUESKY_DID=did:plc:xxx          # Bluesky DID
BLUESKY_ACCESS_TOKEN=xxx         # Bluesky session token
MASTODON_INSTANCE=https://...    # Mastodon instance URL
MASTODON_TOKEN=xxx               # Mastodon bearer token
```

---

## File Manifest

```
workflows/
  scbe_content_publisher.workflow.json
  scbe_web_agent_tasks.workflow.json
  m5_mesh_data_funnel.workflow.json
  vertex_hf_pipeline.workflow.json
  x_growth_merch_ops.workflow.json
  asana_aetherbrowse_scheduler.workflow.json
  game_events.workflow.json
  scbe_telegram_local_router.workflow.json
  scbe_telegram_webhook_cloud.workflow.json
  scbe_llm_dispatch.workflow.json
  notion_github_swarm_research.workflow.json
  baserow_releases_rss.workflow.json
bridge/
  scbe_n8n_bridge.py
  import_workflows.ps1
samples/
  llm_dispatch_payload.sample.json
  notion_github_swarm_payload.sample.json
  x_ops_queue.sample.json
```

---

## Support

- GitHub: https://github.com/issdandavis/SCBE-AETHERMOORE
- Issues: https://github.com/issdandavis/SCBE-AETHERMOORE/issues

## License

Commercial license. Single-user, non-transferable. See LICENSE.txt.
