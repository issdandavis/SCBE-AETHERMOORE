# AI Governance Toolkit

**By Issac Davis / AethermoorGames**
**Version**: 1.0.0
**Patent Pending** (USPTO #63/961,403)

---

## What You Get

A practical toolkit for adding mathematical governance to your AI systems:

### 1. Governance Calculator (`governance_calculator.py`)
Interactive Python tool that computes risk scores using the SCBE 14-layer model:
- Input: agent state vector (6D-9D)
- Output: ALLOW / QUARANTINE / ESCALATE / DENY with confidence scores
- Configurable thresholds for your use case

### 2. Risk Scoring Templates (`templates/`)
Pre-configured governance profiles:
- `chatbot_governance.yaml` — Customer service chatbot safety rails
- `code_agent_governance.yaml` — Coding assistant boundaries
- `research_agent_governance.yaml` — Web research agent limits
- `content_moderation_governance.yaml` — Content review pipeline
- `fleet_governance.yaml` — Multi-agent swarm coordination

### 3. Integration Examples (`examples/`)
Drop-in code for popular frameworks:
- `langchain_hook.py` — LangChain before/after tool call governance
- `openai_wrapper.py` — OpenAI API call wrapper with risk gating
- `fastapi_middleware.py` — FastAPI middleware for governed endpoints
- `n8n_webhook.py` — n8n webhook for governance-as-a-service

### 4. The 14-Layer Reference (`docs/14_layer_guide.md`)
Plain-English guide to each layer:
- What it does
- Why it matters
- How to configure it
- Real-world examples

### 5. Threat Library (`threats/`)
200+ categorized threat patterns with governance responses:
- Prompt injection variants
- Data exfiltration attempts
- Privilege escalation patterns
- Social engineering templates

---

## Quick Start

```python
from governance_calculator import GovernanceCalculator

gc = GovernanceCalculator(profile="chatbot_governance")

# Check if an action is safe
result = gc.evaluate(
    agent_state=[0.1, 0.2, 0.05, 0.3, 0.1, 0.15],
    intent="answer_user_question",
    context={"topic": "weather", "user_tier": "free"}
)

print(result.decision)      # "ALLOW"
print(result.risk_score)    # 0.12
print(result.confidence)    # 0.94
print(result.layer_scores)  # {L5: 0.08, L12: 0.15, L13: 0.12}
```

---

## The Math (Simplified)

The core formula that makes attacks infeasible:

```
H(d, R) = R^(d^2)
```

Where:
- `d` = hyperbolic distance from safe center (Poincare ball)
- `R` = scaling factor (default 1.5, the Perfect Fifth ratio)
- At d=0 (safe): H = 1 (no penalty)
- At d=2: H = 1.5^4 = 5.06x cost
- At d=5: H = 1.5^25 = 25,251x cost
- At d=10: H = 1.5^100 = 406 QUADRILLION x cost

Adversarial behavior isn't just hard -- it's mathematically infeasible.

---

## Requirements

- Python 3.11+
- No external dependencies (stdlib only for calculator)
- Optional: numpy, scipy for advanced spectral analysis

## License

Commercial license. Single-team, non-transferable. See LICENSE.txt.
