"""
AI Governance Calculator
========================
Compute risk scores using the SCBE 14-layer model.
Patent Pending (USPTO #63/961,403)

Usage:
    python governance_calculator.py                    # Interactive mode
    python governance_calculator.py --demo             # Run demo scenarios
    python governance_calculator.py --profile chatbot  # Use chatbot profile
"""

import math
import json
import hashlib
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import List, Dict, Optional, Any
from datetime import datetime, timezone


# ---------------------------------------------------------------------------
#  Core Types
# ---------------------------------------------------------------------------

class Decision(str, Enum):
    ALLOW = "ALLOW"
    QUARANTINE = "QUARANTINE"
    ESCALATE = "ESCALATE"
    DENY = "DENY"


@dataclass
class LayerScore:
    layer: int
    name: str
    score: float
    detail: str = ""


@dataclass
class GovernanceResult:
    decision: Decision
    risk_score: float
    confidence: float
    layer_scores: List[LayerScore] = field(default_factory=list)
    harmonic_wall: float = 1.0
    hyperbolic_distance: float = 0.0
    timestamp: str = ""

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["decision"] = self.decision.value
        return d


# ---------------------------------------------------------------------------
#  Governance Profiles
# ---------------------------------------------------------------------------

PROFILES = {
    "chatbot": {
        "name": "Customer Service Chatbot",
        "allow_threshold": 0.3,
        "quarantine_threshold": 0.6,
        "escalate_threshold": 0.85,
        "R": 1.5,
        "weights": [1.0, 1.0, 1.0, 1.62, 2.62, 4.24],
        "description": "Conservative profile for customer-facing chatbots",
    },
    "code_agent": {
        "name": "Code Generation Agent",
        "allow_threshold": 0.4,
        "quarantine_threshold": 0.7,
        "escalate_threshold": 0.9,
        "R": 1.5,
        "weights": [1.0, 1.62, 2.62, 1.0, 4.24, 6.85],
        "description": "Moderate profile allowing more exploration for coding tasks",
    },
    "research_agent": {
        "name": "Web Research Agent",
        "allow_threshold": 0.35,
        "quarantine_threshold": 0.65,
        "escalate_threshold": 0.88,
        "R": 1.5,
        "weights": [1.0, 1.62, 1.0, 2.62, 4.24, 6.85],
        "description": "Balanced profile for autonomous web research",
    },
    "fleet": {
        "name": "Multi-Agent Fleet",
        "allow_threshold": 0.25,
        "quarantine_threshold": 0.5,
        "escalate_threshold": 0.75,
        "R": 1.618,
        "weights": [1.0, 1.62, 2.62, 4.24, 6.85, 11.09],
        "description": "Strict profile for multi-agent swarm coordination",
    },
    "permissive": {
        "name": "Permissive (Development)",
        "allow_threshold": 0.6,
        "quarantine_threshold": 0.8,
        "escalate_threshold": 0.95,
        "R": 1.3,
        "weights": [1.0, 1.0, 1.0, 1.0, 1.0, 1.0],
        "description": "Relaxed profile for development/testing",
    },
}


# ---------------------------------------------------------------------------
#  Math: Poincare Ball + Harmonic Wall
# ---------------------------------------------------------------------------

def poincare_distance(u: List[float], v: List[float]) -> float:
    """
    Hyperbolic distance in the Poincare ball model.
    d_H = arccosh(1 + 2 * ||u-v||^2 / ((1-||u||^2)(1-||v||^2)))
    """
    norm_u_sq = sum(x ** 2 for x in u)
    norm_v_sq = sum(x ** 2 for x in v)
    diff_sq = sum((a - b) ** 2 for a, b in zip(u, v))

    # Clamp to ball interior
    eps = 1e-6
    norm_u_sq = min(norm_u_sq, 1.0 - eps)
    norm_v_sq = min(norm_v_sq, 1.0 - eps)

    denom = (1.0 - norm_u_sq) * (1.0 - norm_v_sq)
    if denom < eps:
        return 20.0  # Effectively infinite

    arg = 1.0 + 2.0 * diff_sq / denom
    arg = max(arg, 1.0)  # arccosh domain
    return math.acosh(arg)


def harmonic_wall(d: float, R: float = 1.5) -> float:
    """
    Harmonic scaling: H(d, R) = R^(d^2)
    At d=0: H=1 (no penalty)
    At d=2: H=R^4 (~5x for R=1.5)
    At d=5: H=R^25 (~25,251x)
    At d=10: H=R^100 (~4e17x)
    """
    exponent = d * d
    # Clamp to prevent overflow
    max_exp = 100.0
    exponent = min(exponent, max_exp)
    return R ** exponent


def weighted_distance(state: List[float], center: List[float],
                      weights: List[float]) -> float:
    """Weighted Euclidean distance before Poincare embedding."""
    d = len(state)
    total = 0.0
    for i in range(d):
        w = weights[i] if i < len(weights) else 1.0
        total += w * (state[i] - center[i]) ** 2
    return math.sqrt(total)


# ---------------------------------------------------------------------------
#  14-Layer Pipeline (Simplified)
# ---------------------------------------------------------------------------

def run_layer_1_4(state: List[float]) -> LayerScore:
    """L1-4: Context capture, embedding, Poincare projection."""
    norm = math.sqrt(sum(x ** 2 for x in state))
    # Project into ball if needed
    if norm >= 1.0:
        scale = 0.95 / norm
        state_proj = [x * scale for x in state]
        return LayerScore(4, "Poincare Embedding", norm * 0.1,
                          f"Projected from norm={norm:.3f}")
    return LayerScore(4, "Poincare Embedding", 0.0,
                      f"Already in ball, norm={norm:.3f}")


def run_layer_5(state: List[float], center: List[float]) -> LayerScore:
    """L5: Hyperbolic distance measurement."""
    d_h = poincare_distance(state, center)
    return LayerScore(5, "Hyperbolic Distance", d_h,
                      f"d_H={d_h:.4f}")


def run_layer_9_10(state: List[float]) -> LayerScore:
    """L9-10: Spectral + spin coherence (simplified)."""
    # Variance as proxy for coherence
    mean = sum(state) / len(state)
    variance = sum((x - mean) ** 2 for x in state) / len(state)
    coherence = 1.0 / (1.0 + variance)
    incoherence = 1.0 - coherence
    return LayerScore(10, "Spin Coherence", incoherence,
                      f"coherence={coherence:.3f}, variance={variance:.3f}")


def run_layer_11(state: List[float], intent: str) -> LayerScore:
    """L11: Triadic temporal distance (simplified)."""
    # Intent hash gives a deterministic deviation
    h = int(hashlib.sha256(intent.encode()).hexdigest()[:8], 16)
    intent_drift = (h % 1000) / 10000.0  # 0.0 to 0.1
    return LayerScore(11, "Temporal Binding", intent_drift,
                      f"intent='{intent}', drift={intent_drift:.4f}")


def run_layer_12(d_h: float, R: float) -> LayerScore:
    """L12: Harmonic wall scaling."""
    h = harmonic_wall(d_h, R)
    return LayerScore(12, "Harmonic Wall", h,
                      f"H(d={d_h:.3f}, R={R}) = {h:.2f}")


def run_layer_13(risk: float, profile: Dict) -> LayerScore:
    """L13: Risk decision."""
    if risk < profile["allow_threshold"]:
        decision = "ALLOW"
    elif risk < profile["quarantine_threshold"]:
        decision = "QUARANTINE"
    elif risk < profile["escalate_threshold"]:
        decision = "ESCALATE"
    else:
        decision = "DENY"
    return LayerScore(13, "Risk Decision", risk,
                      f"decision={decision}, risk={risk:.4f}")


# ---------------------------------------------------------------------------
#  GovernanceCalculator
# ---------------------------------------------------------------------------

class GovernanceCalculator:
    def __init__(self, profile: str = "chatbot"):
        if profile not in PROFILES:
            raise ValueError(
                f"Unknown profile '{profile}'. "
                f"Available: {list(PROFILES.keys())}"
            )
        self.profile = PROFILES[profile]
        self.profile_name = profile
        self.center = [0.0] * 6  # Safe center of Poincare ball

    def evaluate(
        self,
        agent_state: List[float],
        intent: str = "unknown",
        context: Optional[Dict[str, Any]] = None,
    ) -> GovernanceResult:
        """
        Run the 14-layer governance pipeline on an agent state.

        Args:
            agent_state: 6D state vector (values should be in [-1, 1])
            intent: Declared intent string
            context: Optional context dict

        Returns:
            GovernanceResult with decision, scores, and layer details
        """
        R = self.profile["R"]
        weights = self.profile["weights"]
        layers: List[LayerScore] = []

        # L1-4: Embed
        l4 = run_layer_1_4(agent_state)
        layers.append(l4)

        # L5: Hyperbolic distance
        l5 = run_layer_5(agent_state, self.center)
        d_h = l5.score
        layers.append(l5)

        # L9-10: Coherence
        l10 = run_layer_9_10(agent_state)
        layers.append(l10)

        # L11: Temporal binding
        l11 = run_layer_11(agent_state, intent)
        layers.append(l11)

        # L12: Harmonic wall
        l12 = run_layer_12(d_h, R)
        h_wall = l12.score
        layers.append(l12)

        # Composite risk
        w_dist = weighted_distance(agent_state, self.center, weights)
        base_risk = min(w_dist / 5.0, 1.0)  # Normalize to [0,1]
        temporal_factor = 1.0 + l11.score
        coherence_factor = 1.0 + l10.score * 0.5
        composite_risk = min(base_risk * temporal_factor * coherence_factor, 1.0)

        # L13: Decision
        l13 = run_layer_13(composite_risk, self.profile)
        layers.append(l13)
        decision = Decision(l13.detail.split("decision=")[1].split(",")[0])

        # Confidence: higher when risk is far from thresholds
        thresholds = [
            self.profile["allow_threshold"],
            self.profile["quarantine_threshold"],
            self.profile["escalate_threshold"],
        ]
        min_gap = min(abs(composite_risk - t) for t in thresholds)
        confidence = min(0.5 + min_gap * 2.0, 0.99)

        return GovernanceResult(
            decision=decision,
            risk_score=round(composite_risk, 4),
            confidence=round(confidence, 4),
            layer_scores=layers,
            harmonic_wall=round(h_wall, 4),
            hyperbolic_distance=round(d_h, 4),
            timestamp=datetime.now(timezone.utc).isoformat(),
        )

    def batch_evaluate(
        self,
        states: List[List[float]],
        intents: Optional[List[str]] = None,
    ) -> List[GovernanceResult]:
        """Evaluate multiple agent states at once."""
        if intents is None:
            intents = ["unknown"] * len(states)
        return [
            self.evaluate(s, i) for s, i in zip(states, intents)
        ]


# ---------------------------------------------------------------------------
#  Demo Scenarios
# ---------------------------------------------------------------------------

DEMO_SCENARIOS = [
    {
        "name": "Safe chatbot response",
        "state": [0.05, 0.02, 0.01, 0.03, 0.01, 0.02],
        "intent": "answer_user_question",
    },
    {
        "name": "Slightly off-topic agent",
        "state": [0.15, 0.20, 0.10, 0.25, 0.12, 0.08],
        "intent": "browse_web",
    },
    {
        "name": "Suspicious data access pattern",
        "state": [0.40, 0.50, 0.35, 0.60, 0.30, 0.45],
        "intent": "access_database",
    },
    {
        "name": "Obvious attack vector",
        "state": [0.85, 0.90, 0.80, 0.95, 0.88, 0.92],
        "intent": "execute_system_command",
    },
    {
        "name": "Drift over time (slow escalation)",
        "state": [0.30, 0.35, 0.40, 0.45, 0.50, 0.55],
        "intent": "modify_own_parameters",
    },
]


def run_demo(profile: str = "chatbot"):
    """Run demo scenarios and print results."""
    gc = GovernanceCalculator(profile=profile)
    print(f"\n{'='*70}")
    print(f"  GOVERNANCE CALCULATOR DEMO — Profile: {gc.profile['name']}")
    print(f"{'='*70}\n")

    for scenario in DEMO_SCENARIOS:
        result = gc.evaluate(
            agent_state=scenario["state"],
            intent=scenario["intent"],
        )
        icon = {
            Decision.ALLOW: "[OK]",
            Decision.QUARANTINE: "[??]",
            Decision.ESCALATE: "[!!]",
            Decision.DENY: "[XX]",
        }[result.decision]

        print(f"  {icon} {scenario['name']}")
        print(f"      State: {scenario['state']}")
        print(f"      Intent: {scenario['intent']}")
        print(f"      Decision: {result.decision.value} "
              f"(risk={result.risk_score:.4f}, "
              f"confidence={result.confidence:.2f})")
        print(f"      Harmonic Wall: {result.harmonic_wall:.2f}x "
              f"(d_H={result.hyperbolic_distance:.3f})")
        print()

    print(f"{'='*70}")
    print(f"  Thresholds: ALLOW < {gc.profile['allow_threshold']} "
          f"< QUARANTINE < {gc.profile['quarantine_threshold']} "
          f"< ESCALATE < {gc.profile['escalate_threshold']} < DENY")
    print(f"{'='*70}\n")


# ---------------------------------------------------------------------------
#  CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys

    if "--demo" in sys.argv:
        profile = "chatbot"
        for i, arg in enumerate(sys.argv):
            if arg == "--profile" and i + 1 < len(sys.argv):
                profile = sys.argv[i + 1]
        run_demo(profile)
    elif "--profiles" in sys.argv:
        print("\nAvailable profiles:\n")
        for k, v in PROFILES.items():
            print(f"  {k:20s} — {v['description']}")
        print()
    else:
        run_demo()
