# Content Spin Engine

**By Issac Davis / AethermoorGames**
**Version**: 1.0.0

---

## What You Get

A complete content multiplication pipeline that turns 5 topics into 63+ unique variations across 7 platforms -- all with built-in quality governance.

### How It Works

```
1 Topic Seed
    |
    v
Fibonacci Relay Branching (1 -> 3 -> 9 -> 27)
    |
    v
7 Platform Voices (LinkedIn, Twitter, Bluesky, Medium, Mastodon, GitHub, HuggingFace)
    |
    v
Governance Gate (scan for threats, quality check)
    |
    v
63+ Unique Content Variations
```

### Files Included

| File | Purpose |
|------|---------|
| `content_spin.py` | Core engine -- PivotKnowledge graph, Fibonacci relay, 7 platform voices |
| `revenue_engine.py` | Orchestrator -- hub content, spoke variations, governance gate, queue management |
| `visualize_spin.py` | 3D visualizations of topic topology, relay chains, harmonic spectrum |
| `shopify_bridge.py` | Connect content queue to Shopify blog + products |
| `topics.yaml` | Customizable topic graph (29 nodes, fully connected) |
| `voices.yaml` | Platform voice profiles with harmonic ratios |

### Key Features

- **Fibonacci branching**: Mathematically sound 1-3-9-27 relay chain expansion
- **4D context vectors**: Wave-based patterns (time, context, Fibonacci, harmonic)
- **Harmonic ratios**: Each platform gets a musical frequency ratio for unique character
- **Governance gate**: Every variation scanned before publishing
- **Deterministic**: Same seed = same output (hash-based, reproducible)
- **No API keys needed**: Pure local computation, publish when ready

---

## Quick Start

```bash
# Generate all variations from default topics
python content_spin.py

# Generate for a specific topic
python revenue_engine.py spin ai_governance 3

# Generate hub + spoke content
python revenue_engine.py generate

# Visualize the topic graph
python visualize_spin.py
```

### Customize Topics

Edit the `PivotKnowledge` topic graph in `content_spin.py`:

```python
self.graph = {
    "your_topic": ["related_1", "related_2", "related_3"],
    "related_1": ["your_topic", "related_2"],
    # ... fully connected graph
}
```

### Customize Platform Voices

Each platform has a harmonic ratio, tone, and structure:

```python
PLATFORM_VOICES = {
    "your_platform": {
        "harmonic": "perfect_fifth",  # 3/2 ratio
        "tone": "conversational",
        "max_length": 500,
        "structure": "hook + insight + call_to_action",
    }
}
```

---

## Output Format

Each variation is a JSON file in the output queue:

```json
{
  "id": "056464e81def",
  "topic": "ai_governance",
  "platform": "linkedin",
  "angle": "ai governance through the lens of trust",
  "body": "...",
  "tags": ["AIGovernance", "Trust"],
  "harmonic_freq": 1.5,
  "context_vector": [3.14, 2.71, 0.0, 4.71],
  "status": "spun"
}
```

---

## Requirements

- Python 3.11+
- matplotlib (for visualizations only)
- No API keys needed for generation

## License

Commercial license. Single-user. See LICENSE.txt.
